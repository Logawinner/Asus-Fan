#include <gtk/gtk.h>
#include <vector>
#include <string>
#include <algorithm>
#include <iostream>
#include <cmath>

/**
 * ============================================================================
 * Apostle Fan - Thermal Management Suite
 * Version: 23.0.0 (Graph Restored - Identity Corrected)
 * ============================================================================
 */

struct CurvePoint {
    double x; // Temperature (C)
    double y; // Fan Speed (%)
};

struct FanAppData {
    GtkWidget *window;
    GtkWidget *drawing_area;
    std::vector<CurvePoint> points;
    int selected_point = -1;
    int hover_point = -1;
    
    FanAppData() {
        points = {{20, 10}, {40, 25}, {60, 50}, {80, 80}, {95, 100}};
    }
};

const char *ASUS_UI_CSS = 
    "window { background-image: linear-gradient(135deg, #0f0202 0%, #020f05 45%, #02050f 100%) !important; } "
    ".main-viewport { padding: 45px; } "
    ".persistent-bar { background: rgba(10, 10, 10, 1.0); border-bottom: 2px solid transparent; "
    "background-image: linear-gradient(rgba(10,10,10,1.0), rgba(10,10,10,1.0)), "
    "linear-gradient(90deg, #ff00ff 0%, #00ffff 25%, #00ff00 50%, #ffff00 75%, #ff00ff 100%); "
    "background-origin: padding-box, border-box; background-clip: padding-box, border-box; padding: 5px 20px; } "
    ".control-label { font-weight: 900; color: #ffffff; font-size: 16pt; } "
    ".nav-button { background: #151515; border: 1px solid #00ffff; border-radius: 4px; padding: 5px 15px; color: #00ffff; font-weight: bold; margin-left: 8px; } "
    ".nav-button:hover { background: #004422; color: #ffffff; border-color: #00ff88; } "
    ".nav-button.exit:hover { background: #880000; color: #fff; border-color: #ff0000; } "
    ".tool-btn { background: #000; color: #00ffff; border: 1px solid #00ffff; font-weight: bold; padding: 8px 16px; margin-right: 10px; } "
    "button.action-btn { background: #000; color: #00ff88; font-weight: 800; border: 2px solid #00ff88; padding: 22px; font-size: 14pt; margin-top: 15px; } "
    "drawingarea { background: rgba(0,0,0,0.85); border: 1px solid #00ffff; }";

static gboolean on_draw_graph(GtkWidget *widget, cairo_t *cr, gpointer user_data) {
    FanAppData *data = (FanAppData*)user_data;
    GtkAllocation alloc;
    gtk_widget_get_allocation(widget, &alloc);

    // Grid & Axis Labels
    cairo_set_source_rgba(cr, 0.0, 1.0, 1.0, 0.15);
    cairo_set_font_size(cr, 11.0);
    for(int i=0; i<=10; i++) {
        double lx = (alloc.width/10.0)*i;
        double ly = (alloc.height/10.0)*i;
        cairo_move_to(cr, lx, 0); cairo_line_to(cr, lx, alloc.height);
        cairo_move_to(cr, 0, ly); cairo_line_to(cr, alloc.width, ly);
        cairo_stroke(cr);
        
        cairo_set_source_rgb(cr, 0.8, 0.8, 0.8);
        char tx[12], px[12];
        sprintf(tx, "%dC", i*10); 
        sprintf(px, "%d%%", (10-i)*10);
        
        if(i > 0 && i < 10) {
            cairo_move_to(cr, lx+5, alloc.height-5); cairo_show_text(cr, tx);
            cairo_move_to(cr, 5, ly-10); cairo_show_text(cr, px);
        }
    }

    // Thermal Curve
    cairo_set_source_rgb(cr, 0.0, 1.0, 0.5);
    cairo_set_line_width(cr, 4.0);
    for(size_t i=0; i<data->points.size(); ++i) {
        double px = (data->points[i].x / 100.0) * alloc.width;
        double py = (1.0 - data->points[i].y / 100.0) * alloc.height;
        if(i == 0) cairo_move_to(cr, px, py); else cairo_line_to(cr, px, py);
    }
    cairo_stroke(cr);

    // Nodes & Hover Magenta HUD
    for(size_t i=0; i<data->points.size(); ++i) {
        double px = (data->points[i].x/100.0)*alloc.width, py = (1.0-data->points[i].y/100.0)*alloc.height;
        cairo_arc(cr, px, py, 7.5, 0, 2*G_PI);
        if((int)i == data->selected_point || (int)i == data->hover_point) {
            cairo_set_source_rgb(cr, 1.0, 0.0, 1.0); 
            char hud[32]; sprintf(hud, "[ %dC | %d%% ]", (int)data->points[i].x, (int)data->points[i].y);
            cairo_move_to(cr, px+15, py-15); cairo_show_text(cr, hud);
        } else cairo_set_source_rgb(cr, 0.0, 1.0, 1.0);
        cairo_fill(cr);
    }
    return FALSE;
}

static gboolean on_mouse(GtkWidget *widget, GdkEvent *event, gpointer user_data) {
    FanAppData *data = (FanAppData*)user_data;
    GtkAllocation alloc;
    gtk_widget_get_allocation(widget, &alloc);
    double x, y; gdk_event_get_coords(event, &x, &y);

    if (event->type == GDK_BUTTON_PRESS) {
        for(size_t i=0; i<data->points.size(); ++i) {
            double px = (data->points[i].x/100.0)*alloc.width, py = (1.0-data->points[i].y/100.0)*alloc.height;
            if(hypot(x-px, y-py) < 20.0) { data->selected_point = i; break; }
        }
    } else if (event->type == GDK_MOTION_NOTIFY) {
        data->hover_point = -1;
        for(size_t i=0; i<data->points.size(); ++i) {
            double px = (data->points[i].x/100.0)*alloc.width, py = (1.0-data->points[i].y/100.0)*alloc.height;
            if(hypot(x-px, y-py) < 20.0) data->hover_point = i;
        }
        if(data->selected_point != -1) {
            double min_x = (data->selected_point > 0) ? data->points[data->selected_point-1].x + 1 : 0;
            double max_x = (data->selected_point < (int)data->points.size()-1) ? data->points[data->selected_point+1].x - 1 : 100;
            data->points[data->selected_point].x = std::clamp((x/alloc.width)*100.0, min_x, max_x);
            data->points[data->selected_point].y = std::clamp(100.0-(y/alloc.height)*100.0, 0.0, 100.0);
        }
    } else if (event->type == GDK_BUTTON_RELEASE) data->selected_point = -1;
    gtk_widget_queue_draw(widget);
    return TRUE;
}

static void cb_apply(GtkWidget *btn, gpointer user_data) {
    FanAppData *data = (FanAppData*)user_data;
    std::string s = "asusctl fan-curve -f cpu -c \"";
    for(size_t i=0; i<data->points.size(); ++i) {
        s += std::to_string((int)data->points[i].x) + ":" + std::to_string((int)data->points[i].y);
        if(i < data->points.size()-1) s += ",";
    }
    s += "\""; system(s.c_str());
}

static void activate(GtkApplication *app, gpointer user_data) {
    FanAppData *data = (FanAppData*)user_data;
    GtkCssProvider *p = gtk_css_provider_new();
    gtk_css_provider_load_from_data(p, ASUS_UI_CSS, -1, NULL);
    gtk_style_context_add_provider_for_screen(gdk_screen_get_default(), GTK_STYLE_PROVIDER(p), 800);

    data->window = gtk_application_window_new(app);
    gtk_window_set_decorated(GTK_WINDOW(data->window), FALSE);
    
    // Download the fan icon to a temporary location to ensure it works on any PC
    system("curl -sL https://github.com/Logawinner/Asus-Fan/raw/main/Asus_Fan.png -o /tmp/fan_icon.svg");
    gtk_window_set_icon_from_file(GTK_WINDOW(data->window), "/tmp/fan_icon.svg", NULL);

    GtkWidget *overlay = gtk_overlay_new();
    gtk_container_add(GTK_CONTAINER(data->window), overlay);

    // HEADER (Centered Asus, No Fan Icon)
    GtkWidget *header = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    gtk_widget_set_valign(header, GTK_ALIGN_START);
    gtk_style_context_add_class(gtk_widget_get_style_context(header), "persistent-bar");
    
    GtkWidget *spacer_L = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    gtk_box_pack_start(GTK_BOX(header), spacer_L, TRUE, TRUE, 0);

    GtkWidget *title = gtk_label_new("Asus Fan"); 
    gtk_style_context_add_class(gtk_widget_get_style_context(title), "control-label");
    gtk_box_pack_start(GTK_BOX(header), title, FALSE, FALSE, 0);

    GtkWidget *spacer_R = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    gtk_box_pack_start(GTK_BOX(header), spacer_R, TRUE, TRUE, 0);

    GtkWidget *b_min = gtk_button_new_with_label("_");
    GtkWidget *b_exit = gtk_button_new_with_label("X");
    gtk_style_context_add_class(gtk_widget_get_style_context(b_min), "nav-button");
    gtk_style_context_add_class(gtk_widget_get_style_context(b_exit), "nav-button exit");
    g_signal_connect_swapped(b_min, "clicked", G_CALLBACK(gtk_window_iconify), data->window);
    g_signal_connect_swapped(b_exit, "clicked", G_CALLBACK(g_application_quit), app);
    gtk_box_pack_start(GTK_BOX(header), b_min, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(header), b_exit, FALSE, FALSE, 0);
    gtk_overlay_add_overlay(GTK_OVERLAY(overlay), header);

    GtkWidget *view = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
    gtk_style_context_add_class(gtk_widget_get_style_context(view), "main-viewport");
    gtk_container_add(GTK_CONTAINER(overlay), view);

    GtkWidget *pad = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
    gtk_widget_set_size_request(pad, -1, 70);
    gtk_box_pack_start(GTK_BOX(view), pad, FALSE, FALSE, 0);

    // Tools
    GtkWidget *tools = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    GtkWidget *ba = gtk_button_new_with_label("+ ADD POINT"), *br = gtk_button_new_with_label("- REMOVE POINT");
    gtk_style_context_add_class(gtk_widget_get_style_context(ba), "tool-btn");
    gtk_style_context_add_class(gtk_widget_get_style_context(br), "tool-btn");
    g_signal_connect(ba, "clicked", G_CALLBACK(+[](GtkWidget *b, gpointer d){
        FanAppData *f = (FanAppData*)d;
        if(f->points.size() < 12) {
            size_t l = f->points.size()-1;
            f->points.insert(f->points.end()-1, {(f->points[l].x+f->points[l-1].x)/2, (f->points[l].y+f->points[l-1].y)/2});
            gtk_widget_queue_draw(f->drawing_area);
        }
    }), data);
    g_signal_connect(br, "clicked", G_CALLBACK(+[](GtkWidget *b, gpointer d){
        FanAppData *f = (FanAppData*)d;
        if(f->points.size() > 2) { f->points.erase(f->points.end()-2); gtk_widget_queue_draw(f->drawing_area); }
    }), data);
    gtk_box_pack_start(GTK_BOX(tools), ba, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(tools), br, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(view), tools, FALSE, FALSE, 20);

    data->drawing_area = gtk_drawing_area_new();
    gtk_widget_set_size_request(data->drawing_area, -1, 400);
    gtk_widget_add_events(data->drawing_area, GDK_BUTTON_PRESS_MASK | GDK_POINTER_MOTION_MASK | GDK_BUTTON_RELEASE_MASK);
    g_signal_connect(data->drawing_area, "draw", G_CALLBACK(on_draw_graph), data);
    g_signal_connect(data->drawing_area, "event", G_CALLBACK(on_mouse), data);
    gtk_box_pack_start(GTK_BOX(view), data->drawing_area, TRUE, TRUE, 0);

    GtkWidget *b_app = gtk_button_new_with_label("APPLY THERMAL CURVE");
    gtk_style_context_add_class(gtk_widget_get_style_context(b_app), "action-btn");
    g_signal_connect(b_app, "clicked", G_CALLBACK(cb_apply), data);
    gtk_box_pack_start(GTK_BOX(view), b_app, FALSE, FALSE, 0);

    gtk_widget_show_all(data->window);
    gtk_window_maximize(GTK_WINDOW(data->window));
}

int main(int argc, char **argv) {
    FanAppData *d = new FanAppData();
    GtkApplication *a = gtk_application_new("org.apostle.fan", G_APPLICATION_FLAGS_NONE);
    g_signal_connect(a, "activate", G_CALLBACK(activate), d);
    return g_application_run(G_APPLICATION(a), argc, argv);
}